<link href="bootstrap-5.2.0-beta1-dist/css/bootstrap.css" rel="stylesheet">
<script src="bootstrap-5.2.0-beta1-dist/js/bootstrap.bundle.js"></script>
<link href="style.css" rel="stylesheet">
<script src="scripts.js"></script>